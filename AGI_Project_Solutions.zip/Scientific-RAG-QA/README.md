# Scientific-RAG-QA

This project contains code for Scientific RAG QA.
