# Prompt-Chaining-CoT

This project contains code for Prompt Chaining CoT.
